package Code;

public interface Problem5_calcPlanInterface {

	public int getShares();

}
