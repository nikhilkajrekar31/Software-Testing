package Code;

public enum Problem2_sodaEnum { Start, S0, S1, S2, S3};